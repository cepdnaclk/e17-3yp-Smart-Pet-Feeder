import React from "react";

import Users from "../../components/Users/Users";


const AdminUserPage = () => {
  return (
    <React.Fragment>
      <Users />
    </React.Fragment>
  );
};

export default AdminUserPage;
