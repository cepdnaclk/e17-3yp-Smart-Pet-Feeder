import React from "react";

const AttributeNav = ({ children }) => {
  return <div className="attr-nav">{children}</div>;
};

export default AttributeNav;
